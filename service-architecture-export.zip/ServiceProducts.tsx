import type { ProductTab } from '../../../types/service';

interface ServiceProductsProps {
  tabs: ProductTab[];
  title?: string;
}

export const ServiceProducts = ({ tabs, title = "En enklere hverdag for deg og din bedrift" }: ServiceProductsProps) => {
  if (tabs.length === 0) {
    return null;
  }

  return (
    <section id="fordeler" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
            {title}
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Vi skreddersyr oppdraget etter dine behov. Klikk deg gjennom fanene for å se hva vi kan hjelpe deg med.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
              Alt du trenger for en ryddig økonomi
            </h2>
            <p className="text-lg text-slate-600 mb-8">
              Vi skreddersyr oppdraget etter dine behov. Enten du vil gjøre mye selv i skyen, eller sette bort hele papirmølla til oss.
            </p>

            <div className="space-y-6">
              {[
                { title: "Løpende regnskap & bokføring", desc: "Digital bilagsflyt og effektiv bokføring." },
                { title: "Lønnskjøring & A-melding", desc: "Korrekt lønn til rett tid, inkludert alle rapporter." },
                { title: "Årsoppgjør & Skattemelding", desc: "Vi tar oss av årsoppgjøret og dialog med Altinn." },
                { title: "Fakturering & Purring", desc: "Sikre likviditeten med gode rutiner for innbetaling." },
                { title: "Økonomisk Rådgivning", desc: "Strategisk sparringspartner for vekst og utvikling." }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <svg className="w-6 h-6 text-[#E86C1F] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 1 0 18 0z" />
                  </svg>
                  <div>
                    <h4 className="font-bold text-slate-900">{item.title}</h4>
                    <p className="text-sm text-slate-600">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-50">
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800"
                alt="Digitalt Regnskap"
                className="w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-slate-900/90 backdrop-blur-sm p-6 text-white">
                <p className="font-bold text-lg mb-1">Full oversikt – alltid</p>
                <p className="text-sm text-slate-300">Vi bruker Tripletex, PowerOffice Go og Duett for sømløs samhandling.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};