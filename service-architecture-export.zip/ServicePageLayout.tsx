import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import type { ServicePageConfig } from '../../types/service';
import { ServiceHero } from '../modules/service/ServiceHero';
import { ServiceProducts } from '../modules/service/ServiceProducts';
import { ServiceSales } from '../modules/service/ServiceSales';
import { ServiceFAQ } from '../modules/service/ServiceFAQ';
import { ServiceArticles } from '../modules/service/ServiceArticles';

interface Props {
  config: ServicePageConfig;
}

export const ServicePageLayout = ({ config }: Props) => {
  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <title>{config.hero.title} | Averdi</title>
        <meta name="description" content={config.hero.subtitle} />
      </Helmet>

      <main className="min-h-screen bg-white">
        <ServiceHero
          data={config.hero}
          onCtaClick={() => navigate('/kontakt')}
        />
        <ServiceProducts tabs={config.products} />
        <ServiceSales profile={config.expert} theme={config.hero.theme} />
        <ServiceFAQ items={config.faq} />
        <ServiceArticles tag={config.articleTag} />
      </main>
    </>
  );
};