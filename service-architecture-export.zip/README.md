# Service Architecture Export

This package contains a complete modular service architecture for React applications, specifically designed for service-based pages like accounting, consulting, and business services.

## 📦 Package Contents

### Core Architecture
- `types/service.ts` - TypeScript interfaces for service pages
- `components/ui/SplitProfileCard.tsx` - Reusable expert profile component
- `components/modules/service/` - Modular service components
- `components/templates/ServicePageLayout.tsx` - Master layout template

### Example Implementations
- `pages/services/RegnskapPage.tsx` - Accounting service example
- `pages/services/LonnPage.tsx` - Payroll service example
- `pages/services/RaadgivingPage.tsx` - Consulting service example
- `pages/services/FaktureringPage.tsx` - Invoicing service example

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install react-helmet-async react-router-dom framer-motion lucide-react
```

### 2. Import the Service Layout
```typescript
import { ServicePageLayout } from './components/templates/ServicePageLayout';
import { ServicePageConfig } from './types/service';
```

### 3. Create a Service Page
```typescript
export function MyServicePage() {
  const config: ServicePageConfig = {
    hero: {
      title: "Your Service Title",
      subtitle: "Your service description",
      theme: "orange" // or "blue", "green", "slate"
    },
    products: [
      {
        id: "product1",
        title: "Service 1",
        description: "Description of service 1",
        icon: SomeIconFromLucide,
        image: "https://example.com/image.jpg",
        features: ["Feature 1", "Feature 2", "Feature 3"]
      }
    ],
    expert: {
      name: "Expert Name",
      role: "Expert Title",
      quote: "Expert quote about the service",
      image: "https://example.com/expert.jpg",
      email: "expert@example.com",
      phone: "123456789"
    },
    faq: [
      {
        question: "Frequent question?",
        answer: "Helpful answer to the question"
      }
    ],
    articleTag: "service-tag"
  };

  return <ServicePageLayout config={config} />;
}
```

## 🏗️ Architecture Overview

### Type Definitions
- `ServiceTheme`: Theme options for styling
- `ServiceHeroData`: Hero section configuration
- `ProductTab`: Product/service tab configuration
- `ExpertProfile`: Expert profile data
- `FAQItem`: FAQ question/answer pair
- `ServicePageConfig`: Complete page configuration

### Modular Components
1. **ServiceHero**: Animated hero section with gradient blobs
2. **ServiceProducts**: Product tabs with feature lists
3. **ServiceSales**: Expert profile + sales pitch
4. **ServiceFAQ**: Accordion-style FAQ section
5. **ServiceArticles**: Related articles grid

### Features
- ✅ Responsive design (mobile & desktop)
- ✅ Themed components (orange, blue, green, slate)
- ✅ SEO optimized with Helmet
- ✅ Reusable across multiple service pages
- ✅ Consistent styling and structure
- ✅ Easy to customize and extend

## 🎨 Customization

### Themes
Change the theme by modifying the `theme` property in the hero config:
```typescript
theme: "orange" | "blue" | "green" | "slate"
```

### Icons
Use any icon from `lucide-react` for product tabs:
```typescript
import { YourIcon } from 'lucide-react';

// In product config:
icon: YourIcon
```

### Styling
The components use Tailwind CSS for styling. You can customize:
- Colors in the theme configuration
- Spacing and layout in the component files
- Animations in the motion configurations

## 📚 Usage Examples

### Accounting Service (Regnskap)
```typescript
// See RegnskapPage.tsx for complete example
```

### Payroll Service (Lønn)
```typescript
// See LonnPage.tsx for complete example
```

### Consulting Service (Rådgivning)
```typescript
// See RaadgivingPage.tsx for complete example
```

### Invoicing Service (Fakturering)
```typescript
// See FaktureringPage.tsx for complete example
```

## 🔧 Technical Requirements
- React 18+
- TypeScript 4.9+
- Tailwind CSS
- Framer Motion
- Lucide React Icons
- React Helmet Async
- React Router DOM

## 📈 Benefits
- **Consistency**: All service pages have identical structure
- **Maintainability**: Update one module, all pages benefit
- **Scalability**: Add new service pages with minimal effort
- **Performance**: Reduced bundle size through code reuse
- **Developer Experience**: Clear separation of concerns

This architecture is production-ready and can be easily integrated into any React project that needs service-based pages with consistent design and functionality.